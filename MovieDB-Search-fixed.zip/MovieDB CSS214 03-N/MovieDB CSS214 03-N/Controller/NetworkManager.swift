//
//  NetworkManager.swift
//  MovieDB CSS214 03-N
//
//  Created by Ерош Айтжанов on 30.10.2026.
//

import Foundation

class NetworkManager {
    static let shared = NetworkManager()

    private func makeURL(path: String, queryItems: [URLQueryItem] = []) -> URL? {
        var urlComponent = URLComponents()
        urlComponent.scheme = "https"
        urlComponent.host = "api.themoviedb.org"
        urlComponent.path = path
        urlComponent.queryItems = [
            URLQueryItem(name: "api_key", value: "WRITE HERE YOUR OWN API KEY!")
        ]
        urlComponent.queryItems?.append(contentsOf: queryItems)
        return urlComponent.url
    }

    private let urlImage: String = "https://image.tmdb.org/t/p/w500/"

    func loadMovie(completion: @escaping ([Result]) -> Void) {
        guard let url = makeURL(path: "/3/movie/now_playing") else { return }

        let session = URLSession(configuration: .ephemeral)
        DispatchQueue.global().async {
            let task = session.dataTask(with: url) { data, response, error in
                if let error {
                    print("! ERROR loadMovie !")
                    let nsError = error as NSError

                    print("Error domain:", nsError.domain)
                    print("Error code:", nsError.code)
                    print("Error description", nsError.localizedDescription)
                }

                guard let data = data else { return }

//                let json = try? JSONSerialization.jsonObject(with: data)
//                print(json)

                if let movie = try? JSONDecoder().decode(Movie.self, from: data) {
                    DispatchQueue.main.async {
                        // A missing/invalid API key can return no results. Keep the
                        // Home screen empty instead of crashing on a force unwrap.
                        completion(movie.results ?? [])
                    }
                }
            }

            task.resume()
        }
    }

    // Returns the task so the search screen can cancel an old request.
    @discardableResult
    func searchMovies(query: String, completion: @escaping ([Result], String?) -> Void) -> URLSessionDataTask? {
        let items = [
            URLQueryItem(name: "query", value: query),
            URLQueryItem(name: "include_adult", value: "false")
        ]
        guard let url = makeURL(path: "/3/search/movie", queryItems: items) else {
            completion([], "Could not create the search URL.")
            return nil
        }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    if (error as NSError).code == NSURLErrorCancelled { return }
                    completion([], "Could not load movies. Check your connection and try again.")
                    return
                }
                guard let response = response as? HTTPURLResponse else {
                    completion([], "No response from the server. Please try again.")
                    return
                }
                guard (200..<300).contains(response.statusCode) else {
                    let message = response.statusCode == 401
                        ? "Add your TMDB API key in NetworkManager.swift."
                        : "Could not load movies. Please try again."
                    completion([], message)
                    return
                }
                guard let data = data,
                      let movie = try? JSONDecoder().decode(Movie.self, from: data),
                      let results = movie.results else {
                    completion([], "Could not read the movie results.")
                    return
                }
                completion(results, nil)
            }
        }
        task.resume()
        return task
    }

    func loadImage(posterPath: String, completion: @escaping (Data) -> Void) {
        guard let url = URL(string: urlImage + posterPath) else { return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil, let data = data,
                  let response = response as? HTTPURLResponse,
                  (200..<300).contains(response.statusCode) else { return }
            DispatchQueue.main.async {
                completion(data)
            }
        }.resume()
    }

    func loadMovieDetail(movieID: Int, completion: @escaping (MovieDetail) -> Void) {
        guard let url = makeURL(path: "/3/movie/\(movieID)") else { return }

        let session = URLSession(configuration: .ephemeral)
        DispatchQueue.global().async {
            session.dataTask(with: url) { data, response, error in
                guard let data else { return }
                guard let movie = try? JSONDecoder().decode(MovieDetail.self, from: data) else { return }
                DispatchQueue.main.async {
                    completion(movie)
                }
            }.resume()
        }
    }

    func loadCasts(movieID: Int, completion: @escaping ([Cast]) -> Void) {
        guard let url = makeURL(path: "/3/movie/\(movieID)/casts") else { return }

        let session = URLSession(configuration: .ephemeral)
        DispatchQueue.global().async {
            session.dataTask(with: url) { data, response, error in
                guard let data else { return }
                guard let casts = try? JSONDecoder().decode(Casts.self, from: data) else { return }
                DispatchQueue.main.async {
                    completion(casts.cast)
                }
            }.resume()
        }
    }

    func loadVideo(movieID: Int, completion: @escaping ([ResultV]) -> Void) {
        guard let url = makeURL(path: "/3/movie/\(movieID)/videos") else { return }

        let session = URLSession(configuration: .ephemeral)
        DispatchQueue.global().async {
            session.dataTask(with: url) { data, response, error in
                guard let data else { return }
                guard let videos = try? JSONDecoder().decode(Video.self, from: data) else { return }
                DispatchQueue.main.async {
                    completion(videos.results)
                }
            }.resume()
        }
    }
}
