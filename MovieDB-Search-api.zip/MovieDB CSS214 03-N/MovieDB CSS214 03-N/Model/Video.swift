//
//  Video.swift
//  MovieDB CSS214 03-N
//
//  Created by Ерош Айтжанов on 09.11.2026.
//

import Foundation

// MARK: - Video
struct Video: Codable {
    let id: Int
    let results: [ResultV]

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case results = "results"
    }
}

// MARK: - ResultV
struct ResultV: Codable {
    let iso639_1: String?
    let iso3166_1: String?
    let name: String?
    let key: String
    let site: String?
    let size: Int?
    let type: String
    let official: Bool?
    let id: String?
    let publishedAt: String?

    enum CodingKeys: String, CodingKey {
        case iso639_1 = "iso_639_1"
        case iso3166_1 = "iso_3166_1"
        case name = "name"
        case key = "key"
        case site = "site"
        case size = "size"
        case type = "type"
        case official = "official"
        case id = "id"
        case publishedAt = "published_at"
    }
}
