import Foundation

struct FavoriteMovie: Codable {
    let id: Int
    let title: String
    let rating: Double
}

class FavoritesManager {
    static let shared = FavoritesManager()
    private let key = "savedFavoriteMovies"

    var movies: [FavoriteMovie] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let movies = try? JSONDecoder().decode([FavoriteMovie].self, from: data) else { return [] }
        return movies
    }

    func contains(id: Int) -> Bool {
        movies.contains { $0.id == id }
    }

    func toggle(_ movie: FavoriteMovie) {
        var saved = movies
        if let index = saved.firstIndex(where: { $0.id == movie.id }) {
            saved.remove(at: index)
        } else {
            saved.insert(movie, at: 0)
        }
        if let data = try? JSONEncoder().encode(saved) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
