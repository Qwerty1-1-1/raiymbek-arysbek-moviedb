//
//  ViewController.swift
//  MovieDB CSS214 03-N
//
//  Created by Ерош Айтжанов on 12.10.2026.
//

import UIKit
import SnapKit

class ViewController: UIViewController {

    var movieData: [Result] = []

    lazy var movieLabel: UILabel = {
        let label = UILabel()
        label.text = "Now showing"
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 26, weight: .bold)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    lazy var movieTableView: UITableView = {
        let table = UITableView()
        table.dataSource = self
        table.delegate = self
        table.translatesAutoresizingMaskIntoConstraints = false
        table.register(MovieTableViewCell.self, forCellReuseIdentifier: MovieTableViewCell.identifier)
        table.separatorStyle = .none
        return table
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        apiRequest()
    }

    private func setupUI() {
        title = "MovieDB"
        view.backgroundColor = .systemGroupedBackground
        movieTableView.backgroundColor = .clear
        [movieLabel, movieTableView].forEach {
            view.addSubview($0)
        }

        movieLabel.snp.makeConstraints { make in
            make.top.equalTo(view.safeAreaLayoutGuide).offset(12)
            make.leading.trailing.equalToSuperview().inset(20)
        }
        movieTableView.snp.makeConstraints { make in
            make.top.equalTo(movieLabel.snp.bottom).offset(16)
            make.leading.trailing.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide)
        }
    }

    func apiRequest() {
        NetworkManager.shared.loadMovie { result in
            print("Result:", result)
            self.movieData = result
            self.movieTableView.reloadData()
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movieData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = movieTableView.dequeueReusableCell(
            withIdentifier: MovieTableViewCell.identifier,
            for: indexPath
        ) as? MovieTableViewCell else {
            return UITableViewCell()
        }

        let movie = movieData[indexPath.row]
        cell.movieTitle.text = movie.title
        cell.ratingLabel.text = String(format: "★ %.1f / 10", movie.voteAverage ?? 0)

        NetworkManager.shared.loadImage(posterPath: movie.posterPath!) { data in
            cell.movieImage.image = UIImage(data: data)
        }

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movieDetailVC = MovieDetailViewController()
        let movieID = movieData[indexPath.row].id!
        print("Clicked: \(movieID)")
        movieDetailVC.movieID = movieID
        NetworkManager.shared.loadVideo(movieID: movieID) { result in
            let trailer = result.first(where: { $0.type == "Trailer" }) ?? result.first!
            movieDetailVC.trailerKey = trailer.key
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(movieDetailVC, animated: true)
            }
        }
    }
}

