import UIKit
import SnapKit

class FavoritesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let tableView = UITableView()
    private var movies: [FavoriteMovie] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Favorites"
        view.backgroundColor = .systemGroupedBackground
        tableView.backgroundColor = .clear
        tableView.rowHeight = 80
        tableView.dataSource = self
        tableView.delegate = self
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.edges.equalTo(view.safeAreaLayoutGuide)
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refresh()
    }

    private func refresh() {
        movies = FavoritesManager.shared.movies
        let emptyLabel = UILabel()
        emptyLabel.text = "No favorites yet.\nTap the star on a movie to save it."
        emptyLabel.numberOfLines = 0
        emptyLabel.textAlignment = .center
        emptyLabel.textColor = .secondaryLabel
        tableView.backgroundView = movies.isEmpty ? emptyLabel : nil
        tableView.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movies.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favorite")
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: "favorite")
        let movie = movies[indexPath.row]
        cell.textLabel?.text = movie.title
        cell.textLabel?.numberOfLines = 2
        cell.detailTextLabel?.text = String(format: "★ %.1f / 10", movie.rating)
        cell.detailTextLabel?.textColor = .systemOrange
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let detail = MovieDetailViewController()
        detail.movieID = movies[indexPath.row].id
        navigationController?.pushViewController(detail, animated: true)
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }
        FavoritesManager.shared.toggle(movies[indexPath.row])
        refresh()
    }
}
