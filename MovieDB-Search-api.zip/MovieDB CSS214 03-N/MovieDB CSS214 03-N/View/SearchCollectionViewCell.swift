import UIKit
import SnapKit

class SearchCollectionViewCell: UICollectionViewCell {
    static let identifier = "searchMovie"
    private let posterImageView = UIImageView()
    private let titleLabel = UILabel()
    private let ratingLabel = UILabel()
    private var currentPosterPath: String?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        contentView.backgroundColor = .systemBackground
        contentView.layer.cornerRadius = 14
        contentView.layer.masksToBounds = false
        contentView.layer.shadowColor = UIColor.black.cgColor
        contentView.layer.shadowOpacity = 0.10
        contentView.layer.shadowRadius = 7
        contentView.layer.shadowOffset = CGSize(width: 0, height: 3)
        posterImageView.contentMode = .scaleAspectFill
        posterImageView.clipsToBounds = true
        posterImageView.layer.cornerRadius = 14
        posterImageView.backgroundColor = .secondarySystemBackground
        posterImageView.tintColor = .systemGray3
        titleLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        titleLabel.numberOfLines = 2
        titleLabel.textAlignment = .center
        titleLabel.textColor = .label
        ratingLabel.font = .systemFont(ofSize: 15, weight: .bold)
        ratingLabel.textAlignment = .center
        ratingLabel.layer.cornerRadius = 9
        ratingLabel.clipsToBounds = true

        contentView.addSubview(posterImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(ratingLabel)
        posterImageView.snp.makeConstraints { make in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(posterImageView.snp.width).multipliedBy(1.5)
        }
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(posterImageView.snp.bottom).offset(8)
            make.leading.trailing.equalToSuperview().inset(8)
            make.bottom.lessThanOrEqualToSuperview()
        }
        ratingLabel.snp.makeConstraints { make in
            make.top.trailing.equalTo(posterImageView).inset(10)
            make.width.equalTo(46)
            make.height.equalTo(30)
        }
    }

    func configure(movie: Result) {
        titleLabel.text = movie.title ?? "Untitled"
        let rating = movie.voteAverage ?? 0
        ratingLabel.text = String(format: "%.1f", rating)
        ratingLabel.textColor = rating < 8 ? .white : .black
        if rating < 5 {
            ratingLabel.backgroundColor = .systemRed
        } else if rating < 7 {
            ratingLabel.backgroundColor = .systemGray
        } else if rating < 8 {
            ratingLabel.backgroundColor = UIColor(red: 0.16, green: 0.62, blue: 0.28, alpha: 1)
        } else {
            ratingLabel.backgroundColor = UIColor(red: 0.95, green: 0.76, blue: 0.16, alpha: 1)
        }

        posterImageView.image = UIImage(systemName: "film")
        currentPosterPath = movie.posterPath
        guard let path = movie.posterPath else { return }
        NetworkManager.shared.loadImage(posterPath: path) { [weak self] data in
            // A reused cell may now belong to a different movie.
            guard let self = self, self.currentPosterPath == path else { return }
            self.posterImageView.image = UIImage(data: data) ?? UIImage(systemName: "film")
        }
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        currentPosterPath = nil
        posterImageView.image = nil
        titleLabel.text = nil
        ratingLabel.text = nil
    }
}
