import UIKit
import SnapKit

class SearchViewController: UIViewController {
    private var movies: [Result] = []
    private let searchController = UISearchController(searchResultsController: nil)
    private var searchTimer: Timer?
    private var searchTask: URLSessionDataTask?
    private var searchNumber = 0
    private let messageLabel = UILabel()

    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 14
        layout.minimumLineSpacing = 20
        layout.sectionInset = UIEdgeInsets(top: 16, left: 16, bottom: 20, right: 16)
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.backgroundColor = .systemBackground
        collection.keyboardDismissMode = .onDrag
        collection.dataSource = self
        collection.delegate = self
        collection.register(SearchCollectionViewCell.self,
                            forCellWithReuseIdentifier: SearchCollectionViewCell.identifier)
        return collection
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Search"
        view.backgroundColor = .systemBackground
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Find a movie"
        definesPresentationContext = true

        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { make in
            make.edges.equalTo(view.safeAreaLayoutGuide)
        }

        messageLabel.text = "Search for your next movie"
        messageLabel.textColor = .secondaryLabel
        messageLabel.textAlignment = .center
        messageLabel.numberOfLines = 0
        view.addSubview(messageLabel)
        messageLabel.snp.makeConstraints { make in
            make.center.equalTo(collectionView)
            make.leading.trailing.equalTo(view.safeAreaLayoutGuide).inset(24)
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { _ in
            self.collectionView.collectionViewLayout.invalidateLayout()
        })
    }

    private func searchMovies(query: String, number: Int) {
        searchTask = NetworkManager.shared.searchMovies(query: query) { [weak self] results, errorMessage in
            guard let self = self, number == self.searchNumber else { return }
            self.movies = results
            self.collectionView.reloadData()
            self.messageLabel.text = errorMessage ?? "No movies found. Try another title."
            self.messageLabel.isHidden = !results.isEmpty
        }
    }
}

extension SearchViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        searchTimer?.invalidate()
        searchTask?.cancel()
        // Ignore an older response if the user has already changed the text.
        searchNumber += 1
        let number = searchNumber
        let query = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        movies = []
        collectionView.reloadData()
        messageLabel.isHidden = false

        guard !query.isEmpty else {
            messageLabel.text = "Search for your next movie"
            return
        }
        messageLabel.text = "Searching..."
        // Wait briefly so we do not send a request for every letter.
        searchTimer = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: false) { [weak self] _ in
            self?.searchMovies(query: query, number: number)
        }
    }
}

extension SearchViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: SearchCollectionViewCell.identifier, for: indexPath
        ) as? SearchCollectionViewCell else { return UICollectionViewCell() }
        cell.configure(movie: movies[indexPath.item])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Two margins (16 each), one gap (14), then divide by two columns.
        let width = floor((collectionView.bounds.width - 32 - 14) / 2)
        return CGSize(width: width, height: width * 1.5 + 54)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let movieID = movies[indexPath.item].id else { return }
        searchController.searchBar.resignFirstResponder()
        let detailVC = MovieDetailViewController()
        detailVC.movieID = movieID
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
